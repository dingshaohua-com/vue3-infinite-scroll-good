import Mock from "mockjs";
// 设置拦截ajax请求的相应时间
Mock.setup({
  timeout: "200-600",
});

Mock.mock("/getTeachers", (options) => {
  const params = JSON.parse(options.body);
  const pageSize = params.pageSize ? params.pageSize : 10;
  const totalSize = 50;

  // 假设一共50条数据
  let finalPageSize = null;
  if (pageSize > totalSize) {
    finalPageSize = totalSize;
  } else {
    // 如果剩余数量够一页则按照一页，否则mock的数据数量就是剩余的量
    const surplusData = totalSize - pageSize * (params.pageIndex - 1);
    finalPageSize = surplusData > pageSize ? pageSize : surplusData;
  }
  const pageInfo = {
    pageIndex: params.pageIndex,
    pageSize: pageSize,
    totalSize: totalSize,
  };

  // 如果只有一条数据 mock出来的是对象不是数组？脑残设定智能这样处理
  if (finalPageSize === 1) {
    return {
      pageInfo: {
        ...pageInfo,
        hasMore: false,
      },
      list: [
        {
          name: "小红", //随机生成姓名
          age: 10,
        },
      ],
    };
  }

  return Mock.mock({
    pageInfo: {
      ...pageInfo,
      hasMore: finalPageSize===pageSize,
    },
    [`list|${finalPageSize}`]: [
      {
        name: "@cname", //随机生成姓名
        "age|10-20": 10,
      },
    ],
  });
});
