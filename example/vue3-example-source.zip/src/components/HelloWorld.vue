<template>
  <div class="hello">
    <div
      class="trachers"
      v-infinite-scroll="loadMore"
      infinite-scroll-disabled="busy"
      infinite-scroll-distance="30"
    >
      <div class="tracher" v-for="item in trachers" :key="item.index">
        {{ item.name }}
      </div>
      <div v-if="noMore">到底啦！</div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";
const busy = ref(false);
const trachers = ref([]);
const pageIndex = ref(1);
const noMore = ref(false);
const loadMore = async () => {
  busy.value = true;
  const { data: res } = await axios.get("/getTeachers", {
    data: { pageIndex: pageIndex.value, pageSize: 32 },
  });
  console.log(res.list);
  trachers.value = [...trachers.value, ...res.list];
  busy.value = !res.pageInfo.hasMore;
  noMore.value = !res.pageInfo.hasMore;
  pageIndex.value++;
  console.log("请求了第" + res.pageInfo.pageIndex + "页" + busy.value);
};
</script>
<style scoped>
.trachers {
  height: 300px;
  overflow: auto;
  width: 200px;
}
.tracher {
  background: pink;

  margin-bottom: 10px;
  padding: 10px;
}
</style>
