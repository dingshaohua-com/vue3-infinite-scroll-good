import { createApp } from 'vue'
import App from './App.vue'
import infiniteScroll from './directives/vue-infinite-scroll'
import './utils/my-mock'

createApp(App).use(infiniteScroll).mount('#app')
